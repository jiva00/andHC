package com.example.healthconnect3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.health.connect.client.HealthConnect;
import androidx.health.connect.client.HealthConnectClient;
import androidx.health.connect.client.PermissionRequest;
import androidx.health.connect.client.records.HeartRateRecord;
import androidx.health.connect.client.records.StepsRecord;
import androidx.health.connect.client.request.DataRequest;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private HealthConnectClient healthConnectClient;
    private TextView stepCountView;
    private TextView heartRateView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // UI 연결
        stepCountView = findViewById(R.id.step_count);
        heartRateView = findViewById(R.id.heart_rate);

        // Health Connect 클라이언트 초기화
        healthConnectClient = HealthConnect.getOrCreate(this);

        // 권한 요청 및 데이터 읽기
        requestHealthPermissions();
    }

    private void requestHealthPermissions() {
        // 필요한 권한 설정
        Set<PermissionRequest> permissions = new HashSet<>();
        permissions.add(new PermissionRequest(StepsRecord.class));
        permissions.add(new PermissionRequest(HeartRateRecord.class));

        healthConnectClient.requestPermissions(permissions, granted -> {
            if (granted) {
                // 권한이 부여되면 데이터 읽기 시작
                readHealthData();
            } else {
                // 권한 거부 시 메시지 표시
                Toast.makeText(this, "권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void readHealthData() {
        readStepCount();
        readHeartRate();
    }

    private void readStepCount() {
        try {
            DataRequest<StepsRecord> request = new DataRequest.Builder(StepsRecord.class).build();
            List<StepsRecord> stepsData = healthConnectClient.readData(request);
            int totalSteps = 0;

            for (StepsRecord record : stepsData) {
                totalSteps += record.getSteps();
            }

            stepCountView.setText("걸음 수: " + totalSteps);
        } catch (Exception e) {
            Toast.makeText(this, "걸음수 데이터를 불러오는 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    private void readHeartRate() {
        try {
            DataRequest<HeartRateRecord> request = new DataRequest.Builder(HeartRateRecord.class).build();
            List<HeartRateRecord> heartRateData = healthConnectClient.readData(request);
            float averageHeartRate = 0;

            for (HeartRateRecord record : heartRateData) {
                averageHeartRate += record.getHeartRateValue();
            }
            averageHeartRate /= heartRateData.size();

            heartRateView.setText("심박수: " + averageHeartRate);
        } catch (Exception e) {
            Toast.makeText(this, "심박수 데이터를 불러오는 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
        }
    }
}
